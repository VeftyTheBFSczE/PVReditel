
PORT = 65526                # Port, na kterém bude aplikace naslouchat (rozsah 65525-65535)
BANK_IP = "127.0.0.1"         # IP adresa banky (kód banky). Lze změnit dle potřeby.
DATA_FILE = "bank_data.json"  # Soubor pro persistentní uložení dat (bankovních účtů)
TIMEOUT = 120                  # Timeout pro komunikaci (v sekundách)
