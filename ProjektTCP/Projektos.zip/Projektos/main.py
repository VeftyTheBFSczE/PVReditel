
import socketserver
import config
from bank import Bank
from server import BankRequestHandler, ThreadedTCPServer
import logger_setup
import logging


def main():
    logger_setup.setup_logging()
    logger = logging.getLogger("Main")
    bank = Bank()
    # Přiřadíme instanci banky obsluze požadavků
    BankRequestHandler.bank = bank
    server_address = ('', config.PORT)
    with ThreadedTCPServer(server_address, BankRequestHandler) as server:
        logger.info(f"Server spuštěn na portu {config.PORT}")
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            logger.info("Server se ukončuje.")
            server.shutdown()


if __name__ == "__main__":
    main()
