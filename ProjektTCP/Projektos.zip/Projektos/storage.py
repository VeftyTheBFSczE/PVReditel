
import json
import os
import logging


class Storage:
    def __init__(self, filepath):
        self.filepath = filepath
        self.logger = logging.getLogger("Storage")

    def load_data(self):
        if not os.path.exists(self.filepath):
            self.logger.info("Datový soubor nebyl nalezen, inicializuji nová data.")
            return {"accounts": {}, "next_account": 10000}
        try:
            with open(self.filepath, "r", encoding="utf-8") as f:
                data = json.load(f)
                return data
        except Exception as e:
            self.logger.error(f"Chyba při načítání dat: {e}")
            return {"accounts": {}, "next_account": 10000}

    def save_data(self, data):
        try:
            with open(self.filepath, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=4)
            self.logger.info("Data byla úspěšně uložena.")
        except Exception as e:
            self.logger.error(f"Chyba při ukládání dat: {e}")
