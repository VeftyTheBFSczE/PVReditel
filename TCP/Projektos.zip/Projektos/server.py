import socketserver
import socket
import config
from bank import Bank
import logging

class BankRequestHandler(socketserver.StreamRequestHandler):
    # Instance banky bude při inicializaci serveru přiřazena (BankRequestHandler.bank = bank_instance)
    bank = None

    def handle(self):
        self.request.settimeout(config.TIMEOUT)
        self.logger = logging.getLogger("RequestHandler")
        client_address = self.client_address[0]
        self.logger.info(f"Připojeno: {client_address}")
        try:
            while True:
                data = self.rfile.readline()
                if not data:
                    break  # klient ukončil spojení
                try:
                    command_line = data.decode("utf-8").strip()
                except Exception as e:
                    self.logger.error(f"Chyba při dekódování dat: {e}")
                    break
                if not command_line:
                    continue
                self.logger.info(f"Obdrženo: {command_line}")
                response = self.process_command(command_line)
                self.wfile.write((response + "\n").encode("utf-8"))
                self.wfile.flush()
                self.logger.info(f"Odesláno: {response}")
        except Exception as e:
            self.logger.error(f"Chyba při obsluze klienta: {e}")

    def process_command(self, command_line):
        try:
            parts = command_line.split()
            if len(parts) == 0:
                return "ER Prázdný příkaz."
            cmd = parts[0].upper()

            if cmd == "BC":
                bank_ip = BankRequestHandler.bank.get_bank_code()
                return f"BC {bank_ip}"

            elif cmd == "AC":
                if len(parts) != 1:
                    return "ER Příkaz AC nemá žádné argumenty."
                try:
                    account_number = BankRequestHandler.bank.create_account()
                    bank_ip = BankRequestHandler.bank.get_bank_code()
                    return f"AC {account_number}/{bank_ip}"
                except Exception as e:
                    return f"ER {str(e)}"

            elif cmd == "AD":
                # Syntax: AD <account>/<ip> <amount>
                if len(parts) != 3:
                    return "ER Nesprávný počet argumentů pro AD."
                account_str = parts[1]
                amount_str = parts[2]
                account_num, bank_ip = self.parse_account_string(account_str)
                # Pokud účet patří jiné bance, přepošleme příkaz dál
                if bank_ip != BankRequestHandler.bank.get_bank_code():
                    return self.forward_command(command_line, bank_ip)
                try:
                    amount = int(amount_str)
                    if amount < 0:
                        return "ER Částka musí být nezáporná."
                except ValueError:
                    return "ER Částka není ve správném formátu."
                try:
                    BankRequestHandler.bank.deposit(account_num, amount)
                    return "AD"
                except Exception as e:
                    return f"ER {str(e)}"

            elif cmd == "AW":
                # Syntax: AW <account>/<ip> <amount>
                if len(parts) != 3:
                    return "ER Nesprávný počet argumentů pro AW."
                account_str = parts[1]
                amount_str = parts[2]
                account_num, bank_ip = self.parse_account_string(account_str)
                if bank_ip != BankRequestHandler.bank.get_bank_code():
                    return self.forward_command(command_line, bank_ip)
                try:
                    amount = int(amount_str)
                    if amount < 0:
                        return "ER Částka musí být nezáporná."
                except ValueError:
                    return "ER Částka není ve správném formátu."
                try:
                    BankRequestHandler.bank.withdraw(account_num, amount)
                    return "AW"
                except Exception as e:
                    return f"ER {str(e)}"

            elif cmd == "AB":
                # Syntax: AB <account>/<ip>
                if len(parts) != 2:
                    return "ER Nesprávný počet argumentů pro AB."
                account_str = parts[1]
                account_num, bank_ip = self.parse_account_string(account_str)
                if bank_ip != BankRequestHandler.bank.get_bank_code():
                    return self.forward_command(command_line, bank_ip)
                try:
                    balance = BankRequestHandler.bank.get_balance(account_num)
                    return f"AB {balance}"
                except Exception as e:
                    return f"ER {str(e)}"

            elif cmd == "AR":
                # Syntax: AR <account>/<ip>
                if len(parts) != 2:
                    return "ER Nesprávný počet argumentů pro AR."
                account_str = parts[1]
                account_num, bank_ip = self.parse_account_string(account_str)
                if bank_ip != BankRequestHandler.bank.get_bank_code():
                    return "ER Bankovní účet nepatří této bance."
                try:
                    BankRequestHandler.bank.remove_account(account_num)
                    return "AR"
                except Exception as e:
                    return f"ER {str(e)}"

            elif cmd == "BA":
                if len(parts) != 1:
                    return "ER Příkaz BA nemá žádné argumenty."
                total = BankRequestHandler.bank.get_total_amount()
                return f"BA {total}"

            elif cmd == "BN":
                if len(parts) != 1:
                    return "ER Příkaz BN nemá žádné argumenty."
                count = BankRequestHandler.bank.get_client_count()
                return f"BN {count}"

            else:
                return "ER Neplatný příkaz."
        except Exception as e:
            return f"ER {str(e)}"

    def forward_command(self, command_str, target_ip):
        """
        Přepošle příkaz na server cílové banky.
        """
        try:
            with socket.create_connection((target_ip, config.PORT), timeout=config.TIMEOUT) as sock:
                sock.sendall((command_str + "\n").encode("utf-8"))
                with sock.makefile("r", encoding="utf-8") as f:
                    response = f.readline().strip()
                    return response
        except Exception as e:
            return f"ER Chyba při komunikaci s bankou {target_ip}: {str(e)}"

    def parse_account_string(self, account_str):
        # Očekávaný formát: <account>/<ip>
        if '/' not in account_str:
            raise Exception("Formát čísla účtu není správný.")
        parts = account_str.split('/')
        if len(parts) != 2:
            raise Exception("Formát čísla účtu není správný.")
        account_part, ip_part = parts
        try:
            account_num = int(account_part)
        except ValueError:
            raise Exception("Formát čísla účtu není správný.")
        if account_num < 10000 or account_num > 99999:
            raise Exception("Číslo účtu mimo platný rozsah.")
        if not self.validate_ip(ip_part):
            raise Exception("Formát IP adresy není správný.")
        return account_num, ip_part

    def validate_ip(self, ip):
        parts = ip.split('.')
        if len(parts) != 4:
            return False
        try:
            for p in parts:
                n = int(p)
                if n < 0 or n > 255:
                    return False
            return True
        except ValueError:
            return False

class ThreadedTCPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    allow_reuse_address = True