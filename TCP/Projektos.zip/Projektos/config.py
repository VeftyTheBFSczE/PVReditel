# config.py
PORT = 65530             # Port, na kterém server naslouchá
BANK_IP = "10.2.7.14"      # IP adresa (bankovní kód) této banky
DATA_FILE = "bank_data.json"  # Cesta k souboru s persistentními daty
TIMEOUT = 120              # Timeout pro komunikaci (120 sekund = 2 minuty)
