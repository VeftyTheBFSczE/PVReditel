import threading
import config
from storage import Storage
import logging

class Bank:
    def __init__(self):
        # Používáme reentrantní zámek (RLock), abychom se vyhnuli deadlocku při volání metody save() uvnitř kritické sekce.
        self.lock = threading.RLock()
        self.storage = Storage(config.DATA_FILE)
        data = self.storage.load_data()
        self.accounts = data.get("accounts", {})  # Účty jsou uloženy jako slovník {číslo_účtu: zůstatek}
        self.next_account = data.get("next_account", 10000)
        if self.next_account < 10000:
            self.next_account = 10000
        self.logger = logging.getLogger("Bank")

    def save(self):
        with self.lock:
            data = {
                "accounts": self.accounts,
                "next_account": self.next_account
            }
            self.storage.save_data(data)

    def get_bank_code(self):
        return config.BANK_IP

    def create_account(self):
        with self.lock:
            if self.next_account > 99999:
                raise Exception("Naše banka nyní neumožňuje založení nového účtu.")
            account_number = self.next_account
            self.accounts[str(account_number)] = 0  # Nový účet se zůstatkem 0
            self.next_account += 1
            self.save()
            self.logger.info(f"Vytvořen účet {account_number}")
            return account_number

    def deposit(self, account_number, amount):
        with self.lock:
            key = str(account_number)
            if key not in self.accounts:
                raise Exception("Účet neexistuje.")
            if amount < 0:
                raise Exception("Částka musí být nezáporná.")
            self.accounts[key] += amount
            self.save()
            self.logger.info(f"Na účet {account_number} vloženo {amount}. Nový zůstatek: {self.accounts[key]}")

    def withdraw(self, account_number, amount):
        with self.lock:
            key = str(account_number)
            if key not in self.accounts:
                raise Exception("Účet neexistuje.")
            if amount < 0:
                raise Exception("Částka musí být nezáporná.")
            if self.accounts[key] < amount:
                raise Exception("Není dostatek finančních prostředků.")
            self.accounts[key] -= amount
            self.save()
            self.logger.info(f"Z účtu {account_number} vybráno {amount}. Nový zůstatek: {self.accounts[key]}")

    def get_balance(self, account_number):
        with self.lock:
            key = str(account_number)
            if key not in self.accounts:
                raise Exception("Účet neexistuje.")
            return self.accounts[key]

    def remove_account(self, account_number):
        with self.lock:
            key = str(account_number)
            if key not in self.accounts:
                raise Exception("Účet neexistuje.")
            if self.accounts[key] != 0:
                raise Exception("Nelze smazat bankovní účet na kterém jsou finance.")
            del self.accounts[key]
            self.save()
            self.logger.info(f"Smazán účet {account_number}")

    def get_total_amount(self):
        with self.lock:
            return sum(self.accounts.values())

    def get_client_count(self):
        with self.lock:
            return len(self.accounts)